<template>
  <el-main>
    <!-- 面包屑 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">首页 {{ pageq }}</el-breadcrumb-item>
      <el-breadcrumb-item>活动管理</el-breadcrumb-item>
      <el-breadcrumb-item>活动列表</el-breadcrumb-item>
      <el-breadcrumb-item>活动详情</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 筛选 -->
    <div class="suffix">
      <div class="el-input-suffix">
        <label>状态:</label>
        <el-input placeholder="请输入内容"></el-input>
      </div>
      <div class="el-input-suffix el-select">
        <label>角色名称:</label>
        <el-select placeholder="请选择">
          <el-option
          ></el-option>
        </el-select>
      </div>
      <div class="el-input-suffix">
        <el-button type="primary" icon="el-icon-search">搜索</el-button>
      </div>
    </div>

    <!-- 表格 -->
    <div class="zxl-from">
      <el-card class="box-card">
        <!-- 功能按钮 -->
        <div class="box-head">
          <el-button type="primary" size="mini">新增</el-button>
          <el-button type="primary" size="mini">修改</el-button>
          <el-button type="primary" size="mini">删除</el-button>
          <el-button type="primary" size="mini">刷新</el-button>
          <div style="float:right;display:inline-block">
            <el-popover placement="bottom" title="列筛选" trigger="click">
              <el-checkbox-group v-model="checkList" @change="zxlFilter">
                <el-checkbox
                  v-for="item in tableList"
                  :key="item.label"
                  :label="item.label"
                >{{item.value}}</el-checkbox>
              </el-checkbox-group>
              <el-button size="small" slot="reference">
                <i class="el-icon-arrow-down el-icon-menu"></i>
              </el-button>
            </el-popover>
          </div>
        </div>
        <el-table :data="tableDatas" @selection-change="handleSelectionChange">
          <el-table-column type="selection" width="55"></el-table-column>
          <template v-for="item in tableList">
            <el-table-column
              :key="item.id"
              :prop="item.label"
              :label="item.value"
              v-if="uncheckList[item.label]"
            ></el-table-column>
          </template>
          <!-- <el-table-column prop="name" label="名称" v-if="uncheckList.name"></el-table-column>
          <el-table-column prop="status.name" label="状态" v-if="uncheckList.status"></el-table-column>
          <el-table-column prop="description" label="描述" v-if="uncheckList.description"></el-table-column>
          <el-table-column prop="createUser.name" label="创建人" v-if="uncheckList.createUser"></el-table-column>
          <el-table-column
            prop="createTime"
            label="创建时间"
            v-if="uncheckList.createTime"
          ></el-table-column>
          <el-table-column prop="updateUser.name" label="最后修改人" v-if="uncheckList.updateUser"></el-table-column>
          <el-table-column prop="updateTime" label="最后修改时间" v-if="uncheckList.updateTime"></el-table-column>-->
        </el-table>
      </el-card>
    </div>
  </el-main>
</template>

<style lang="scss">
.el-main {
  .suffix {
    padding: 10px 0;
    border-bottom: 1px solid #eee;
    .el-input-suffix {
      display: inline-block;
      margin-right: 6px;
      label {
        padding: 0 15px;
      }
      .el-input {
        width: 180px;
      }
    }
    .el-select {
      .el-input {
        width: 100px;
      }
    }
  }
  .zxl-from {
    .el-button + .el-button {
      margin-left: 1px;
    }
  }
}
.el-popover {
  .el-checkbox {
    display: block;
    margin-bottom: 6px;
  }
}
</style>

<style lang="scss" scoped>
.box-head {
  border-bottom: 1px solid #eee;
  padding-bottom: 20px;
}
</style>
<script>
import { gettableList } from "../../../static/js/utils";
import qs from 'qs';

export default {
  data() {
    return {
      pageNow: 1,
      pageSize: 10,
      searchParam: {},
      options: [
        {
          value: "选项1",
          label: "11111"
        },
        {
          value: "选项2",
          label: "222"
        }
      ],
      select: "",
      tableData: tableData,
      tableDatas: "",
      tableList: [
        {
          label: "name",
          value: "名称"
        },
        {
          label: "status",
          value: "状态"
        },
        {
          label: "description",
          value: "描述"
        },
        {
          label: "createUser",
          value: "创建人"
        },
        {
          label: "createTime",
          value: "创建时间"
        },
        {
          label: "updateUser",
          value: "最后修改人"
        },
        {
          label: "updateTime",
          value: "最后修改时间"
        }
      ],
      checkListOne: ["name", "status", "description", "createTime"], // 列表初始化显示列
      checkList: [],
      uncheckList: {},
      multipleSelection: [] //选中数据
    };
  },
  created() {
    
  },
  mounted() {
    console.log(this.$qs.stringify({
      pageNow: this.pageNow
    }) + '9999')
    this.getData()
  },
  methods: {
    getData() {
      let page = this.$qs.stringify({
        pageNow: this.pageNow,
        pageSize: 10
      });
      console.log(this.pageNow+ '000')
      axios.post('/znmc/api/role/list', page).then((res) => {
        console.log(res)
      })
    },

    zxlFilter: function(val) {
      // //初始化数据
      if (val == undefined) {
        for (let index in this.tableList) {
          let table = this.tableList[index];
          this.checkList.push(table.label);
          this.uncheckList[table.label] = false;
        }
      }

      // 数据准备
      for (let item in this.uncheckList) {
        this.uncheckList[item] = false;
      }
      //数据处理
      for (let index in this.checkList) {
        let name = this.checkList[index];
        if (name in this.uncheckList) {
          this.uncheckList[name] = true;
        }
      }
      // 初始显示
      if (val == undefined) {
        for (let item in this.uncheckList) {
          this.uncheckList[item] = false;
        }
        for (let index in this.checkListOne) {
          let name = this.checkListOne[index];
          if (name in this.uncheckList) {
            this.uncheckList[name] = true;
          }
        }
        this.checkList = this.checkListOne;
      }
      this.$forceUpdate(); //列表强制刷新
    }
  },
  computed: {}
};
</script>