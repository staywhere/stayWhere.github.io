<template>
  <el-main>{{ data }}</el-main>
</template>

<style lang="scss" scoped>

</style>

<script>
export default {
  data() {
    return {
      data: 'user234567'
    }
  }
}
</script>